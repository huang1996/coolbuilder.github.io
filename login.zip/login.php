<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>服务器发送</title>
</head>
<body>
<?php
$user=$_POST['user'];
$pwd=$_POST['pwd'];
echo "姓名：".$user."<br>";
echo "密码：".$pwd."<br>";
?>
</body>
</html>
